<p align="center"><img src="https://raw.githubusercontent.com/JujuAdams/input/master/LOGO.png" style="display:block; margin:auto; width:300px"></p>
<h1 align="center">Input 5.6.0</h1>

<p align="center">Comprehensive cross-platform input for GameMaker Studio 2022 LTS by <a href="http://www.jujuadams.com/"><b>@jujuadams</b></a> and <a href="https://offalynne.neocities.org/"><b>@offalynne</b></a></p>

&nbsp;

&nbsp;

- ### [Download the .yymps](https://github.com/JujuAdams/input/releases/)
- ### Read the [documentation](http://jujuadams.github.io/Input)
- ### Talk about Input on the [Discord server](https://discord.gg/8krYCqr)
